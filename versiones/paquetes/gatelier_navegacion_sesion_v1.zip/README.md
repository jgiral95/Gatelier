# Gatelier — Ajuste de navegación y sesión

Esta actualización modifica únicamente archivos de frontend:
- Elimina el acceso general a Movimientos de la barra lateral en Inventario, Producción y la página de Movimientos.
- Conserva el acceso a Movimientos desde el botón de cada producto en Inventario.
- Evita el destello de la pantalla de login al volver a Inventario: oculta temporalmente las superficies de login y aplicación mientras se valida la sesión y las muestra al terminar.

No cambia backend, base de datos, `.env`, `compose.yaml` ni los activos del logo.
Instalación recomendada: hacer respaldo de los tres HTML, copiar los archivos y recargar el navegador con Ctrl+F5. No hace falta reconstruir imágenes Docker porque solo cambia HTML estático.
