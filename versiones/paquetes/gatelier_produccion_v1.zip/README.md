# Gatelier — Módulo de producción v1

Actualización incremental sobre la página de movimientos v5. Añade fichas de producción, órdenes por encargo o para inventario, coste de mano de obra por horas, gastos por lote/unidad y distribución de gastos mensuales.

## Comportamiento
- Las fichas asocian un producto clasificado como `Producto terminado` con materiales del inventario, cantidad por unidad y merma opcional.
- La mano de obra se calcula por horas por unidad multiplicadas por la tarifa horaria.
- Los gastos mensuales se distribuyen entre las unidades previstas del mes. Cada orden guarda un snapshot de cantidades y costes.
- Al completar una orden se comprueba el stock y se descuentan materiales en una transacción. Si el destino es inventario, se suman las unidades terminadas y se actualiza su coste promedio. Si es por encargo, no se añade producto al stock disponible.
- Crear/iniciar/cancelar órdenes no cambia existencias; el cambio ocurre solo al completar.
- La migración crea tablas nuevas mediante `CREATE TABLE IF NOT EXISTS`; no elimina ni reescribe datos previos.

## Instalación
1. Haz copia de seguridad de `backend/app/main.py` y `frontend/index.html`.
2. Copia los archivos del ZIP respetando sus rutas. Incluye `frontend/produccion.html`.
3. Ejecuta `docker compose config -q && docker compose up -d --build`.
4. Abre `/produccion.html` y recarga con Ctrl+F5.

No sustituye `.env`, `compose.yaml`, el volumen PostgreSQL ni el logo. El archivo de logo existente se reutiliza sin cambios.
