# Gatelier — Página de movimientos v5

Actualización incremental sobre la versión v4.1. Incluye un historial de movimientos en una página dedicada, búsqueda, filtro por tipo y vista global o por producto.

## Instalación
1. Haz copia de seguridad de `backend/app/main.py` y `frontend/index.html`.
2. Copia estos tres archivos conservando las rutas.
3. Ejecuta `docker compose config -q && docker compose up -d --build`.
4. Recarga el navegador con Ctrl+F5.

No reemplaza `.env`, `compose.yaml`, la base de datos ni el volumen PostgreSQL. No incluye ni modifica el archivo del logo; la página reutiliza `/assets/gatelier-logo-white.png` que ya existe en la instalación.
