# Gatelier — Fichas asociadas y menú uniforme (v1.2)

## Cambios
- Las fichas de producción requieren seleccionar explícitamente un producto de inventario clasificado como `Producto terminado`.
- La API valida el tipo de producto al crear una ficha; las órdenes usan el producto terminado asociado a la ficha.
- No se permite reclasificar un producto terminado como otro tipo mientras tenga fichas de producción activas asociadas.
- Menú lateral uniforme en Inventario, Movimientos y Producción, en el orden: Inventario, Ventas, Producción, Costes.
- Movimientos no aparece en el menú; se accede desde la acción Movimientos de cada artículo del inventario.
- Conserva la corrección para evitar que el login parpadee mientras se verifica la sesión al entrar al inventario.

## Instalación
Respaldar `backend/app/main.py`, `frontend/index.html`, `frontend/movimientos.html` y `frontend/produccion.html`. Copiar los cuatro archivos del ZIP a las rutas correspondientes. No se modifica `.env`, `compose.yaml`, ni se reemplaza la base de datos o los archivos del logo.
