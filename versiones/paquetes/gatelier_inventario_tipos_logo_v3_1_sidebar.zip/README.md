# Gatelier — Inventario v3 (tipos de artículo y logo oficial)

Actualización incremental para la instalación existente de Gatelier. No reemplaza `.env`, `compose.yaml`, la base de datos ni los volúmenes Docker.

## Incluye
- Distingue materias primas, materiales recuperados, productos en proceso, productos terminados y registros heredados por clasificar.
- Precio de venta separado del coste unitario; el precio de venta solo se muestra y edita para productos terminados.
- Filtro por tipo de artículo, además de búsqueda y filtro por nivel de stock.
- Conserva edición de productos, gestión de categorías, ajustes de stock e historial de movimientos.
- Migración PostgreSQL no destructiva: agrega `item_type` y `sale_price`; los artículos existentes quedan como `Por clasificar` para que el equipo decida su tipo en vez de asignarlo automáticamente.
- Incluye `frontend/assets/gatelier-logo-white.png` y usa el wordmark original blanco sin cambiar su tipografía ni proporciones. Solo se elimina el patrón de cuadrícula que venía como fondo de vista previa, para dejar transparencia real; se conserva la proporción original 1774 × 887.
- El puerto 8000 sigue siendo interno a Docker para la API.

## Significado de coste unitario
- Materia prima / material recuperado: coste por unidad de adquisición o recuperación/preparación.
- Producto en proceso: coste acumulado estimado por unidad, hasta que implementemos las órdenes de producción.
- Producto terminado: coste de fabricación por unidad; el precio de venta es otro campo independiente.

## Despliegue seguro
1. Copia este ZIP a `~/gatelier` en el servidor.
2. Desde `~/gatelier`, crea un respaldo de `backend/app/main.py`, `frontend/index.html` y `nginx.conf`.
3. Extrae el ZIP en una carpeta temporal y sustituye únicamente esos tres archivos y la carpeta `frontend/assets/`. No reemplaces `.env`, `compose.yaml`, `backend/app/create_user.py` ni la base de datos.
4. Ejecuta `docker compose config -q`.
5. Ejecuta `docker compose up -d --build` desde `~/gatelier`.
6. Comprueba `docker compose ps`, `docker compose logs --tail=80 db api web` y `curl -i http://localhost:8085/api/health`.

La migración se ejecuta al arrancar la API. No borra ni recrea tablas de inventario existentes. Tras desplegar, revisa los artículos existentes con el filtro **Por clasificar** y asigna el tipo correcto a cada uno.
