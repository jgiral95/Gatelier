# Gatelier — Entrada valorizada y coste promedio ponderado

Actualización incremental sobre el MVP existente. Añade una forma segura de registrar entradas de inventario con coste, manteniendo el historial y calculando el coste promedio ponderado. No incluye `.env`, `compose.yaml`, credenciales ni datos de la base de datos.

## Qué incorpora
- Botón **＋ Entrada** por referencia.
- Registro de cantidad recibida, coste por unidad y nota/origen.
- Cálculo automático del nuevo coste promedio ponderado: `(existencia actual × coste actual + cantidad recibida × coste de entrada) / existencia resultante`.
- La cantidad y el coste promedio se actualizan en una misma transacción de PostgreSQL.
- Historial de movimientos ampliado con el coste promedio resultante en las entradas valorizadas.
- Conserva las funciones previas: edición de referencias, categorías, filtros, ajustes manuales e historial.
- Migración no destructiva que agrega dos columnas opcionales al historial de movimientos. No elimina tablas ni modifica las existencias actuales.

## Cómo usarlo
1. En **Inventario**, pulsa **＋ Entrada** en la referencia correspondiente.
2. Introduce la cantidad y el coste por unidad en COP. Para material recuperado, incluye en ese coste los gastos atribuibles de selección, recuperación y preparación, incluso si el material fue donado.
3. Añade una nota con el origen o el detalle y registra la entrada.
4. El coste unitario de la referencia se actualizará con el promedio ponderado. Para una corrección de conteo o una merma sin valoración, utiliza **± Stock**.

## Despliegue seguro en el servidor
Desde Windows PowerShell, copia el ZIP:

```powershell
scp "$HOME\Downloads\gatelier_entrada_valorizada_v4.zip" gatelier:~/gatelier/
```

Conéctate por SSH y ejecuta:

```bash
cd ~/gatelier
BACKUP="backups/antes-entrada-valorizada-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp backend/app/main.py frontend/index.html "$BACKUP/"
mkdir -p /tmp/gatelier_entrada_valorizada
unzip -o gatelier_entrada_valorizada_v4.zip -d /tmp/gatelier_entrada_valorizada
cp /tmp/gatelier_entrada_valorizada/backend/app/main.py backend/app/main.py
cp /tmp/gatelier_entrada_valorizada/frontend/index.html frontend/index.html
chmod 644 backend/app/main.py frontend/index.html
docker compose config -q && docker compose up -d --build
```

Verifica el estado:

```bash
docker compose ps
docker compose logs --tail=80 api web
curl -i http://localhost:8085/api/health
```

Después, recarga el navegador con `Ctrl+F5`. La migración de las columnas se aplica al iniciar la API. No reemplaces `.env`, `compose.yaml`, `backend/app/create_user.py` ni el volumen PostgreSQL.


## Cantidades según unidad de medida

Las referencias en unidad, rollo o paquete solo admiten cantidades enteras. Esta regla se valida tanto en la interfaz como en la API para existencias iniciales, stock mínimo, entradas valorizadas y ajustes. Metro, centímetro, kilogramo y gramo mantienen cantidades decimales. El servidor rechaza valores no válidos y no permite cambiar a una unidad discreta si las existencias actuales tienen fracciones.
