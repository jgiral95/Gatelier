# Gatelier MVP: login e inventario

Incluye pantalla de inicio de sesión y módulo de inventario conectado a FastAPI/PostgreSQL. El color Cremona se aproxima como #BBE0D7. El texto Gatelier de navegación no sustituye el archivo oficial del logo: si se incorpora el logo, usar el original sin cambiar tipografía ni proporciones.

## Funciones
- Inicio/cierre de sesión con cookie HttpOnly, Secure y SameSite=Lax.
- Inventario por referencia SKU, nombre, categoría, unidad, cantidad, stock mínimo, coste unitario y notas.
- Búsqueda, filtros de stock, valoración estimada y movimientos de entrada/salida.
- Evita existencias negativas; registra movimientos y no elimina tablas existentes.
- Ventas, producción y costes aparecen como módulos futuros, aún no implementados.

## Instalación segura
En el servidor, desde ~/gatelier, crea respaldo de los archivos que vas a reemplazar y sustituye solo backend/app/main.py, frontend/index.html y nginx.conf por los de este paquete. No reemplaces .env ni compose.yaml. Verifica que compose.yaml pasa SESSION_SECRET al servicio api y monta ./nginx.conf:/etc/nginx/conf.d/default.conf:ro en web. Luego ejecuta:
1. docker compose config -q
2. docker compose up -d --build
3. docker compose ps
4. docker compose logs --tail=80 db api web
5. curl -i http://localhost:8085/api/health
6. docker compose exec api python -m app.create_user

El puerto 8000 solo es interno a Docker para la API; no se publica en el host. Antes de producción conviene añadir limitación de intentos de login y probar recuperación de copias de seguridad.
