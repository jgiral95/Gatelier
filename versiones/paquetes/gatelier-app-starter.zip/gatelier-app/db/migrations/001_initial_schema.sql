BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE product_type AS ENUM ('raw_material', 'finished_good', 'packaging', 'service');
CREATE TYPE inventory_movement_type AS ENUM ('opening', 'purchase', 'recovery', 'production_consumption', 'production_output', 'sale', 'customer_return', 'waste', 'adjustment_in', 'adjustment_out');
CREATE TYPE order_status AS ENUM ('draft', 'confirmed', 'in_production', 'ready', 'delivered', 'cancelled');
CREATE TYPE sales_channel AS ENUM ('presencial', 'instagram', 'whatsapp', 'otro');
CREATE TYPE payment_status AS ENUM ('pending', 'confirmed', 'reversed');
CREATE TYPE production_status AS ENUM ('draft', 'planned', 'in_progress', 'completed', 'cancelled');
CREATE TYPE origin_type AS ENUM ('recovered', 'donated', 'purchased', 'other');
CREATE TYPE cash_movement_type AS ENUM ('income', 'expense', 'transfer_in', 'transfer_out', 'refund');

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'operator' CHECK (role IN ('admin', 'operator')),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    category_type TEXT NOT NULL CHECK (category_type IN ('product', 'material', 'expense')),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (name, category_type)
);

CREATE TABLE units (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    dimension TEXT NOT NULL CHECK (dimension IN ('count', 'length', 'mass', 'volume', 'time', 'other')),
    decimal_places SMALLINT NOT NULL DEFAULT 2 CHECK (decimal_places BETWEEN 0 AND 6)
);

INSERT INTO units (code, name, dimension, decimal_places) VALUES
('und', 'Unidad', 'count', 0), ('m', 'Metro', 'length', 3),
('cm', 'Centímetro', 'length', 2), ('g', 'Gramo', 'mass', 2),
('kg', 'Kilogramo', 'mass', 3), ('h', 'Hora', 'time', 2);

CREATE TABLE suppliers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    contact TEXT,
    phone TEXT,
    email TEXT,
    notes TEXT,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sku TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    description TEXT,
    category_id UUID REFERENCES categories(id),
    product_type product_type NOT NULL,
    base_unit_id UUID NOT NULL REFERENCES units(id),
    sale_price NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (sale_price >= 0),
    minimum_stock NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK (minimum_stock >= 0),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE material_lots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL REFERENCES products(id),
    lot_code TEXT NOT NULL UNIQUE,
    origin origin_type NOT NULL DEFAULT 'recovered',
    origin_description TEXT,
    supplier_id UUID REFERENCES suppliers(id),
    received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    usable_quantity NUMERIC(14,3) NOT NULL CHECK (usable_quantity > 0),
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE material_lot_costs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lot_id UUID NOT NULL REFERENCES material_lots(id),
    cost_type TEXT NOT NULL CHECK (cost_type IN ('purchase', 'collection', 'sorting', 'cleaning', 'preparation', 'other')),
    description TEXT,
    amount NUMERIC(14,2) NOT NULL CHECK (amount >= 0),
    incurred_at DATE NOT NULL DEFAULT CURRENT_DATE,
    source_reference TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE inventory_movements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL REFERENCES products(id),
    lot_id UUID REFERENCES material_lots(id),
    movement_type inventory_movement_type NOT NULL,
    quantity_delta NUMERIC(14,3) NOT NULL CHECK (quantity_delta <> 0),
    unit_cost NUMERIC(14,4) NOT NULL DEFAULT 0 CHECK (unit_cost >= 0),
    reference_type TEXT,
    reference_id UUID,
    reason TEXT,
    idempotency_key TEXT UNIQUE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_inventory_movements_product_date ON inventory_movements(product_id, created_at DESC);
CREATE INDEX idx_inventory_movements_lot ON inventory_movements(lot_id);

CREATE VIEW inventory_balances AS
SELECT p.id AS product_id, p.sku, p.name, p.product_type,
       COALESCE(SUM(im.quantity_delta), 0)::NUMERIC(14,3) AS quantity_on_hand,
       p.minimum_stock,
       CASE WHEN COALESCE(SUM(im.quantity_delta), 0) <= p.minimum_stock THEN TRUE ELSE FALSE END AS low_stock
FROM products p
LEFT JOIN inventory_movements im ON im.product_id = p.id
GROUP BY p.id, p.sku, p.name, p.product_type, p.minimum_stock;

CREATE TABLE bom_headers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL REFERENCES products(id),
    version INTEGER NOT NULL CHECK (version > 0),
    output_quantity NUMERIC(14,3) NOT NULL DEFAULT 1 CHECK (output_quantity > 0),
    notes TEXT,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(product_id, version)
);

CREATE TABLE bom_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bom_id UUID NOT NULL REFERENCES bom_headers(id) ON DELETE CASCADE,
    material_id UUID NOT NULL REFERENCES products(id),
    quantity_per_batch NUMERIC(14,4) NOT NULL CHECK (quantity_per_batch > 0),
    expected_waste_pct NUMERIC(5,2) NOT NULL DEFAULT 0 CHECK (expected_waste_pct BETWEEN 0 AND 100),
    UNIQUE(bom_id, material_id)
);

CREATE TABLE labor_rates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    hourly_rate NUMERIC(14,2) CHECK (hourly_rate >= 0),
    fixed_unit_rate NUMERIC(14,2) CHECK (fixed_unit_rate >= 0),
    valid_from DATE NOT NULL DEFAULT CURRENT_DATE,
    valid_to DATE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    CHECK (valid_to IS NULL OR valid_to >= valid_from)
);

CREATE TABLE production_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number BIGINT GENERATED ALWAYS AS IDENTITY UNIQUE,
    product_id UUID NOT NULL REFERENCES products(id),
    bom_id UUID REFERENCES bom_headers(id),
    planned_quantity NUMERIC(14,3) NOT NULL CHECK (planned_quantity > 0),
    produced_quantity NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK (produced_quantity >= 0),
    status production_status NOT NULL DEFAULT 'draft',
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (finished_at IS NULL OR started_at IS NULL OR finished_at >= started_at)
);

CREATE TABLE production_consumptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_order_id UUID NOT NULL REFERENCES production_orders(id),
    material_id UUID NOT NULL REFERENCES products(id),
    lot_id UUID REFERENCES material_lots(id),
    planned_quantity NUMERIC(14,4) NOT NULL DEFAULT 0 CHECK (planned_quantity >= 0),
    actual_quantity NUMERIC(14,4) NOT NULL CHECK (actual_quantity > 0),
    unit_cost NUMERIC(14,4) NOT NULL CHECK (unit_cost >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE production_costs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_order_id UUID NOT NULL REFERENCES production_orders(id),
    cost_type TEXT NOT NULL CHECK (cost_type IN ('labor_time', 'labor_fixed', 'labor_other', 'packaging', 'other')),
    method TEXT NOT NULL CHECK (method IN ('time', 'fixed', 'combined', 'manual')),
    quantity NUMERIC(14,4) NOT NULL DEFAULT 1 CHECK (quantity >= 0),
    rate NUMERIC(14,4) NOT NULL DEFAULT 0 CHECK (rate >= 0),
    amount NUMERIC(14,2) NOT NULL CHECK (amount >= 0),
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sales_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number BIGINT GENERATED ALWAYS AS IDENTITY UNIQUE,
    customer_id UUID REFERENCES customers(id),
    channel sales_channel NOT NULL,
    status order_status NOT NULL DEFAULT 'draft',
    order_date TIMESTAMPTZ NOT NULL DEFAULT now(),
    delivery_date TIMESTAMPTZ,
    subtotal NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (subtotal >= 0),
    discount NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (discount >= 0),
    shipping_cost NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (shipping_cost >= 0),
    total NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (total >= 0),
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (discount <= subtotal)
);

CREATE TABLE sales_order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES sales_orders(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES products(id),
    quantity NUMERIC(14,3) NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(14,2) NOT NULL CHECK (unit_price >= 0),
    discount NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (discount >= 0),
    unit_cost_snapshot NUMERIC(14,4) NOT NULL DEFAULT 0 CHECK (unit_cost_snapshot >= 0),
    line_total NUMERIC(14,2) NOT NULL CHECK (line_total >= 0),
    CHECK (discount <= quantity * unit_price)
);

CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES sales_orders(id),
    amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
    method TEXT NOT NULL CHECK (method IN ('cash', 'bank_transfer', 'card', 'digital_wallet', 'other')),
    status payment_status NOT NULL DEFAULT 'pending',
    paid_at TIMESTAMPTZ,
    reference TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sales_returns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES sales_orders(id),
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'confirmed', 'cancelled')),
    reason TEXT NOT NULL,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sales_return_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    return_id UUID NOT NULL REFERENCES sales_returns(id) ON DELETE CASCADE,
    order_item_id UUID NOT NULL REFERENCES sales_order_items(id),
    quantity NUMERIC(14,3) NOT NULL CHECK (quantity > 0),
    restock_condition TEXT NOT NULL CHECK (restock_condition IN ('resellable', 'repair', 'waste'))
);

CREATE TABLE financial_accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    account_type TEXT NOT NULL CHECK (account_type IN ('cash', 'bank', 'digital_wallet', 'other')),
    opening_balance NUMERIC(14,2) NOT NULL DEFAULT 0,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE expenses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id UUID REFERENCES categories(id),
    supplier_id UUID REFERENCES suppliers(id),
    description TEXT NOT NULL,
    amount NUMERIC(14,2) NOT NULL CHECK (amount >= 0),
    expense_date DATE NOT NULL DEFAULT CURRENT_DATE,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'cancelled')),
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE cash_movements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL REFERENCES financial_accounts(id),
    movement_type cash_movement_type NOT NULL,
    amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
    origin_type TEXT NOT NULL,
    origin_id UUID,
    status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('pending', 'confirmed', 'reversed')),
    description TEXT,
    idempotency_key TEXT UNIQUE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_cash_movements_account_date ON cash_movements(account_id, created_at DESC);

CREATE TABLE audit_log (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    entity_type TEXT NOT NULL,
    entity_id UUID,
    action TEXT NOT NULL,
    before_data JSONB,
    after_data JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_log_entity ON audit_log(entity_type, entity_id, created_at DESC);

CREATE TABLE app_settings (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    updated_by UUID REFERENCES users(id),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO app_settings (key, value) VALUES
('currency', '"COP"'::jsonb),
('timezone', '"America/Bogota"'::jsonb),
('inventory_cost_method', '"moving_weighted_average"'::jsonb);

COMMIT;
