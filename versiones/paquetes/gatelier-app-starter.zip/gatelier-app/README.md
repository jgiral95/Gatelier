# Gatelier — MVP de gestión

Base inicial del proyecto: API FastAPI, PostgreSQL y Docker Compose. La identidad visual deberá usar los recursos originales de Gatelier sin redibujar el logo, cambiar su tipografía ni alterar sus proporciones.

## Alcance actual

- Infraestructura local de desarrollo con API y base de datos.
- Primera migración SQL con catálogo, unidades, lotes de materiales, movimientos de inventario, fichas de fabricación, órdenes de producción, pedidos, pagos, devoluciones, gastos, caja, usuarios y auditoría.
- Endpoints de salud para API y conexión a base de datos.
- Moneda inicial COP y zona horaria America/Bogota.

## Requisitos

- Docker Engine y Docker Compose plugin.
- Un secreto de base de datos definido en `.env`.

## Inicio local

1. Copiar `.env.example` a `.env`.
2. Cambiar `POSTGRES_PASSWORD` por una contraseña larga y única. El valor se pasa como variable independiente, por lo que puede incluir caracteres especiales.
3. Ejecutar `docker compose up -d --build`.
4. Comprobar API: `curl http://127.0.0.1:8000/health`.
5. Comprobar base de datos: `curl http://127.0.0.1:8000/health/db`.
6. Abrir documentación interactiva: `http://127.0.0.1:8000/docs`.

La API está enlazada a `127.0.0.1` para no exponerla directamente a la red. Para acceso remoto, configurar un proxy HTTPS autenticado; no publicar PostgreSQL.

## Migración de base de datos

En la primera inicialización, PostgreSQL ejecuta `db/migrations/001_initial_schema.sql` automáticamente. Los scripts de `docker-entrypoint-initdb.d` solo se ejecutan cuando el volumen de datos está vacío. Si el volumen ya existe, aplicar migraciones mediante una herramienta de migraciones y no borrar datos para forzar la inicialización.

## Importante antes de producción

- La autenticación de usuarios aún no está implementada; no exponer esta API a Internet.
- Configurar backups externos cifrados y probar restauración.
- Añadir migraciones versionadas, pruebas automáticas, autenticación, autorización y auditoría transaccional.
- La base inicial registra movimientos y estructuras; la lógica de negocio para confirmar ventas, fabricación, pagos y reversiones debe implementarse y probarse antes de operar con datos reales.
