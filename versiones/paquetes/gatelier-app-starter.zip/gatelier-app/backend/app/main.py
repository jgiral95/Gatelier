from decimal import Decimal
from typing import Literal
from uuid import UUID

from fastapi import FastAPI, HTTPException, Query, status
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from psycopg import connect
from psycopg.errors import ForeignKeyViolation, OperationalError, UniqueViolation
from psycopg.rows import dict_row


class Settings(BaseSettings):
    db_host: str = "db"
    db_port: int = 5432
    db_name: str = "gatelier"
    db_user: str = "gatelier"
    db_password: str = "gatelier_dev_only"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()


def db_connect(**kwargs):
    return connect(host=settings.db_host, port=settings.db_port, dbname=settings.db_name,
                   user=settings.db_user, password=settings.db_password, **kwargs)


app = FastAPI(title="Gatelier API", version="0.1.0", description="API inicial de gestión de Gatelier")


class ProductCreate(BaseModel):
    sku: str = Field(min_length=1, max_length=80)
    name: str = Field(min_length=1, max_length=200)
    description: str | None = None
    category_id: UUID | None = None
    product_type: Literal["raw_material", "finished_good", "packaging", "service"]
    base_unit_id: UUID
    sale_price: Decimal = Field(default=Decimal("0"), ge=0, max_digits=14, decimal_places=2)
    minimum_stock: Decimal = Field(default=Decimal("0"), ge=0, max_digits=14, decimal_places=3)


@app.get("/health", tags=["system"])
def health():
    return {"status": "ok", "service": "gatelier-api", "version": app.version}


@app.get("/health/db", tags=["system"])
def database_health():
    try:
        with db_connect(connect_timeout=3) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return {"status": "ok", "database": "reachable"}
    except OperationalError as exc:
        raise HTTPException(status_code=503, detail="Database unavailable") from exc


@app.get("/api/units", tags=["catalog"])
def list_units():
    with db_connect(row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT id, code, name, dimension, decimal_places FROM units ORDER BY name")
            return cur.fetchall()


@app.get("/api/categories", tags=["catalog"])
def list_categories(category_type: Literal["product", "material", "expense"] | None = None):
    with db_connect(row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            if category_type:
                cur.execute(
                    "SELECT id, name, category_type, active FROM categories WHERE active = TRUE AND category_type = %s ORDER BY name",
                    (category_type,),
                )
            else:
                cur.execute("SELECT id, name, category_type, active FROM categories WHERE active = TRUE ORDER BY name")
            return cur.fetchall()


@app.get("/api/products", tags=["catalog"])
def list_products(
    search: str | None = Query(default=None, max_length=100),
    product_type: Literal["raw_material", "finished_good", "packaging", "service"] | None = None,
    active: bool = True,
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
):
    clauses = ["p.active = %s"]
    params: list[object] = [active]
    if search:
        clauses.append("(p.sku ILIKE %s OR p.name ILIKE %s)")
        params.extend([f"%{search}%", f"%{search}%"])
    if product_type:
        clauses.append("p.product_type = %s")
        params.append(product_type)
    params.extend([limit, offset])
    sql = f"""
        SELECT p.id, p.sku, p.name, p.description, p.product_type,
               p.sale_price, p.minimum_stock, p.active,
               p.category_id, c.name AS category_name,
               p.base_unit_id, u.code AS unit_code, u.name AS unit_name,
               COALESCE(ib.quantity_on_hand, 0) AS quantity_on_hand,
               COALESCE(ib.low_stock, p.minimum_stock > 0) AS low_stock
        FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        JOIN units u ON u.id = p.base_unit_id
        LEFT JOIN inventory_balances ib ON ib.product_id = p.id
        WHERE {' AND '.join(clauses)}
        ORDER BY p.name
        LIMIT %s OFFSET %s
    """
    with db_connect(row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.fetchall()


@app.post("/api/products", tags=["catalog"], status_code=status.HTTP_201_CREATED)
def create_product(product: ProductCreate):
    try:
        with db_connect(row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO products
                       (sku, name, description, category_id, product_type, base_unit_id, sale_price, minimum_stock)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                       RETURNING id, sku, name, description, category_id, product_type, base_unit_id, sale_price, minimum_stock, active, created_at""",
                    (product.sku.strip(), product.name.strip(), product.description, product.category_id,
                     product.product_type, product.base_unit_id, product.sale_price, product.minimum_stock),
                )
                return cur.fetchone()
    except UniqueViolation as exc:
        raise HTTPException(status_code=409, detail="Ya existe un producto con ese SKU") from exc
    except ForeignKeyViolation as exc:
        raise HTTPException(status_code=422, detail="La categoría o unidad indicada no existe") from exc
