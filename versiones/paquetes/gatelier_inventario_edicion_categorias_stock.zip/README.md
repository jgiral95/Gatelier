# Gatelier — actualización de inventario

Actualización incremental para la instalación existente de Gatelier. No reemplaza `.env`, `compose.yaml`, la base de datos ni los volúmenes Docker.

## Incluye
- Edición de producto (SKU, nombre, categoría, unidad, stock mínimo, coste unitario y notas).
- La cantidad actual no se modifica desde el formulario de edición; se cambia mediante un movimiento de entrada o salida para mantener trazabilidad.
- Ajustes de stock con cantidad, motivo y validación para impedir existencias negativas.
- Historial de movimientos por producto.
- Gestión de categorías: crear, renombrar y eliminar si no hay productos que la usen.
- Migración automática y no destructiva: crea `inventory_categories` y registra las categorías que ya existían en `inventory_products`.
- Mantiene la pantalla de acceso, el estilo visual y la API existente.

El color de marca se aproxima con `#BBE0D7`. No se modifica ningún archivo de logo; si se incorpora el logo oficial, debe conservar su tipografía y proporciones originales.

## Despliegue seguro
1. Copia este ZIP a `~/gatelier` en el servidor.
2. Desde `~/gatelier`, crea un respaldo de `backend/app/main.py`, `frontend/index.html` y `nginx.conf`.
3. Extrae el ZIP en una carpeta temporal y sustituye únicamente esos tres archivos. No reemplaces `.env`, `compose.yaml`, `backend/app/create_user.py` ni la base de datos.
4. Ejecuta `docker compose config -q`.
5. Ejecuta `docker compose up -d --build` desde `~/gatelier`.
6. Comprueba `docker compose ps`, `docker compose logs --tail=80 db api web` y `curl -i http://localhost:8085/api/health`.

La migración se ejecuta al arrancar la API. No borra ni recrea tablas de inventario existentes. El puerto 8000 sigue siendo interno a Docker.
