import os
from contextlib import asynccontextmanager
from datetime import datetime,timedelta,timezone
from decimal import Decimal
import jwt, psycopg
from fastapi import FastAPI,Form,HTTPException,Query,Request,Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel,Field
from pwdlib import PasswordHash
from psycopg.errors import UniqueViolation

DATABASE_URL = os.environ["DATABASE_URL"]
DB = DATABASE_URL
SECRET = os.environ["SESSION_SECRET"]
COOKIE="gatelier_session"; HOURS=8; hasher=PasswordHash.recommended()

@asynccontextmanager
async def lifespan(app):
    with psycopg.connect(DB) as c:
        c.execute("""CREATE TABLE IF NOT EXISTS app_users(
        id BIGSERIAL PRIMARY KEY, username VARCHAR(80) UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,is_active BOOLEAN NOT NULL DEFAULT TRUE,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")
        c.execute("""CREATE TABLE IF NOT EXISTS inventory_products(
        id BIGSERIAL PRIMARY KEY,sku VARCHAR(80) UNIQUE NOT NULL,name VARCHAR(180) NOT NULL,
        category VARCHAR(100) NOT NULL DEFAULT 'Sin categoría',unit VARCHAR(30) NOT NULL DEFAULT 'unidad',
        quantity NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK(quantity>=0),
        min_stock NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK(min_stock>=0),
        unit_cost NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK(unit_cost>=0),notes TEXT NOT NULL DEFAULT '',
        is_active BOOLEAN NOT NULL DEFAULT TRUE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")
        c.execute("""CREATE TABLE IF NOT EXISTS inventory_movements(
        id BIGSERIAL PRIMARY KEY,product_id BIGINT NOT NULL REFERENCES inventory_products(id),
        user_id BIGINT REFERENCES app_users(id),movement_type VARCHAR(30) NOT NULL,
        quantity_delta NUMERIC(14,3) NOT NULL,quantity_after NUMERIC(14,3) NOT NULL,
        note TEXT NOT NULL DEFAULT '',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")
        c.execute("""CREATE TABLE IF NOT EXISTS inventory_categories(
        id BIGSERIAL PRIMARY KEY, name VARCHAR(100) UNIQUE NOT NULL,
        is_active BOOLEAN NOT NULL DEFAULT TRUE,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")
        # Importa las categorías que ya existen sin alterar los productos actuales.
        c.execute("""INSERT INTO inventory_categories(name)
        SELECT DISTINCT COALESCE(NULLIF(BTRIM(category), ''), 'Sin categoría')
        FROM inventory_products ON CONFLICT (name) DO NOTHING""")
    yield

app=FastAPI(title="Gatelier API",version="0.3.0",lifespan=lifespan)
def user_from(request):
    token=request.cookies.get(COOKIE)
    if not token: raise HTTPException(401,"Debes iniciar sesión")
    try: uid=int(jwt.decode(token,SECRET,algorithms=["HS256"])["sub"])
    except (jwt.InvalidTokenError,KeyError,ValueError,TypeError): raise HTTPException(401,"Sesión inválida o vencida")
    with psycopg.connect(DB) as c: u=c.execute("SELECT id,username,is_active FROM app_users WHERE id=%s",(uid,)).fetchone()
    if not u or not u[2]: raise HTTPException(401,"Usuario inactivo")
    return {"id":u[0],"username":u[1]}
def pack(r):
    return {"id":r[0],"sku":r[1],"name":r[2],"category":r[3],"unit":r[4],"quantity":r[5],"min_stock":r[6],"unit_cost":r[7],"notes":r[8],"updated_at":r[9]}
class Product(BaseModel):
    sku:str=Field(min_length=1,max_length=80); name:str=Field(min_length=1,max_length=180)
    category:str=Field(default="Sin categoría",max_length=100); unit:str=Field(default="unidad",max_length=30)
    quantity:Decimal=Field(default=Decimal(0),ge=0); min_stock:Decimal=Field(default=Decimal(0),ge=0)
    unit_cost:Decimal=Field(default=Decimal(0),ge=0); notes:str=Field(default="",max_length=4000)
class ProductUpdate(BaseModel):
    sku:str=Field(min_length=1,max_length=80); name:str=Field(min_length=1,max_length=180)
    category:str=Field(default="Sin categoría",max_length=100); unit:str=Field(default="unidad",max_length=30)
    min_stock:Decimal=Field(ge=0); unit_cost:Decimal=Field(ge=0); notes:str=Field(default="",max_length=4000)
class CategoryCreate(BaseModel):
    name:str=Field(min_length=1,max_length=100)
class CategoryUpdate(BaseModel):
    name:str=Field(min_length=1,max_length=100)
class Adjustment(BaseModel):
    delta:Decimal=Field(gt=0,le=999999999); direction:str; note:str=Field(default="",max_length=500)

@app.get("/health")
def health():
    try:
        with psycopg.connect(DB,connect_timeout=3) as c:c.execute("SELECT 1")
        return {"status":"ok","database":"connected"}
    except Exception:return JSONResponse(status_code=503,content={"status":"error","database":"unavailable"})
@app.post("/auth/login")
def login(response:Response,username:str=Form(...),password:str=Form(...)):
    with psycopg.connect(DB) as c:u=c.execute("SELECT id,username,password_hash,is_active FROM app_users WHERE username=%s",(username.strip(),)).fetchone()
    if not u or not u[3] or not hasher.verify(password,u[2]):raise HTTPException(401,"Usuario o contraseña incorrectos")
    now=datetime.now(timezone.utc); token=jwt.encode({"sub":str(u[0]),"iat":now,"exp":now+timedelta(hours=HOURS)},SECRET,algorithm="HS256")
    response.set_cookie(COOKIE,token,max_age=HOURS*3600,httponly=True,secure=True,samesite="lax",path="/")
    return {"message":"Sesión iniciada","username":u[1]}
@app.get("/auth/me")
def me(request:Request):return user_from(request)
@app.post("/auth/logout")
def logout(response:Response):
    response.delete_cookie(COOKIE,path="/",secure=True,httponly=True,samesite="lax");return {"message":"Sesión cerrada"}
@app.get("/dashboard")
def dashboard(request:Request):
    u=user_from(request);return {"message":"Bienvenido a Gatelier","username":u["username"],"modules":["Inventario","Ventas","Producción","Costes"]}
@app.get("/categories")
def list_categories(request:Request):
    user_from(request)
    with psycopg.connect(DB) as c:
        rows=c.execute("SELECT id,name FROM inventory_categories WHERE is_active ORDER BY name").fetchall()
    return {"items":[{"id":r[0],"name":r[1]} for r in rows]}

@app.post("/categories",status_code=201)
def create_category(d:CategoryCreate,request:Request):
    user_from(request); name=d.name.strip()
    if not name: raise HTTPException(422,"El nombre de la categoría es obligatorio")
    try:
        with psycopg.connect(DB) as c:
            r=c.execute("INSERT INTO inventory_categories(name) VALUES(%s) RETURNING id,name",(name,)).fetchone()
        return {"id":r[0],"name":r[1]}
    except UniqueViolation: raise HTTPException(409,"Ya existe una categoría con ese nombre")

@app.patch("/categories/{category_id}")
def rename_category(category_id:int,d:CategoryUpdate,request:Request):
    user_from(request); name=d.name.strip()
    if not name: raise HTTPException(422,"El nombre de la categoría es obligatorio")
    try:
        with psycopg.connect(DB) as c:
            old=c.execute("SELECT name FROM inventory_categories WHERE id=%s AND is_active FOR UPDATE",(category_id,)).fetchone()
            if not old: raise HTTPException(404,"Categoría no encontrada")
            c.execute("UPDATE inventory_categories SET name=%s,updated_at=NOW() WHERE id=%s",(name,category_id))
            c.execute("UPDATE inventory_products SET category=%s,updated_at=NOW() WHERE category=%s",(name,old[0]))
            r=c.execute("SELECT id,name FROM inventory_categories WHERE id=%s",(category_id,)).fetchone()
        return {"id":r[0],"name":r[1]}
    except UniqueViolation: raise HTTPException(409,"Ya existe una categoría con ese nombre")

@app.delete("/categories/{category_id}")
def delete_category(category_id:int,request:Request):
    user_from(request)
    with psycopg.connect(DB) as c:
        cat=c.execute("SELECT name FROM inventory_categories WHERE id=%s AND is_active FOR UPDATE",(category_id,)).fetchone()
        if not cat: raise HTTPException(404,"Categoría no encontrada")
        used=c.execute("SELECT COUNT(*) FROM inventory_products WHERE is_active AND category=%s",(cat[0],)).fetchone()[0]
        if used: raise HTTPException(409,f"No se puede eliminar: {used} producto(s) usan esta categoría. Reasígnalos primero.")
        c.execute("UPDATE inventory_categories SET is_active=FALSE,updated_at=NOW() WHERE id=%s",(category_id,))
    return {"message":"Categoría eliminada"}

@app.get("/inventory")
def inventory(request:Request,search:str=Query("",max_length=120),status:str=Query("all",pattern="^(all|low|ok)$")):
    user_from(request);term=f"%{search.strip()}%"
    with psycopg.connect(DB) as c:
        rows=c.execute("""SELECT id,sku,name,category,unit,quantity,min_stock,unit_cost,notes,updated_at FROM inventory_products
        WHERE is_active AND (%s='' OR sku ILIKE %s OR name ILIKE %s OR category ILIKE %s)
        AND (%s='all' OR (%s='low' AND quantity<=min_stock) OR (%s='ok' AND quantity>min_stock)) ORDER BY name""",
        (search.strip(),term,term,term,status,status,status)).fetchall()
        totals=c.execute("""SELECT COUNT(*),COUNT(*) FILTER(WHERE quantity<=min_stock),COALESCE(SUM(quantity*unit_cost),0)
        FROM inventory_products WHERE is_active""").fetchone()
    return {"items":[pack(r) for r in rows],"summary":{"products":totals[0],"low_stock":totals[1],"inventory_value":totals[2]}}
@app.post("/inventory",status_code=201)
def create_product(d:Product,request:Request):
    u=user_from(request);sku=d.sku.strip();name=d.name.strip()
    if not sku or not name:raise HTTPException(422,"Referencia y nombre son obligatorios")
    try:
        with psycopg.connect(DB) as c:
            r=c.execute("""INSERT INTO inventory_products(sku,name,category,unit,quantity,min_stock,unit_cost,notes)
            VALUES(%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id,sku,name,category,unit,quantity,min_stock,unit_cost,notes,updated_at""",
            (sku,name,d.category.strip() or "Sin categoría",d.unit.strip() or "unidad",d.quantity,d.min_stock,d.unit_cost,d.notes.strip())).fetchone()
            if d.quantity>0:c.execute("""INSERT INTO inventory_movements(product_id,user_id,movement_type,quantity_delta,quantity_after,note)
            VALUES(%s,%s,'initial',%s,%s,'Existencia inicial')""",(r[0],u["id"],d.quantity,d.quantity))
        return pack(r)
    except UniqueViolation:raise HTTPException(409,"Ya existe un producto con esa referencia (SKU)")
@app.patch("/inventory/{pid}")
def update_product(pid:int,d:ProductUpdate,request:Request):
    user_from(request); sku=d.sku.strip(); name=d.name.strip(); category=d.category.strip() or "Sin categoría"
    if not sku or not name: raise HTTPException(422,"Referencia y nombre son obligatorios")
    try:
        with psycopg.connect(DB) as c:
            row=c.execute("SELECT id FROM inventory_products WHERE id=%s AND is_active FOR UPDATE",(pid,)).fetchone()
            if not row: raise HTTPException(404,"Producto no encontrado")
            out=c.execute("""UPDATE inventory_products SET sku=%s,name=%s,category=%s,unit=%s,
            min_stock=%s,unit_cost=%s,notes=%s,updated_at=NOW() WHERE id=%s
            RETURNING id,sku,name,category,unit,quantity,min_stock,unit_cost,notes,updated_at""",
            (sku,name,category,d.unit.strip() or "unidad",d.min_stock,d.unit_cost,d.notes.strip(),pid)).fetchone()
        return pack(out)
    except UniqueViolation: raise HTTPException(409,"Ya existe un producto con esa referencia (SKU)")

@app.post("/inventory/{pid}/adjust")
def adjust(pid:int,d:Adjustment,request:Request):
    u=user_from(request)
    if d.direction not in ("add","remove"):raise HTTPException(422,"Dirección inválida")
    delta=d.delta if d.direction=="add" else -d.delta
    with psycopg.connect(DB) as c:
        r=c.execute("SELECT id,quantity FROM inventory_products WHERE id=%s AND is_active FOR UPDATE",(pid,)).fetchone()
        if not r:raise HTTPException(404,"Producto no encontrado")
        new=r[1]+delta
        if new<0:raise HTTPException(409,"El ajuste dejaría el inventario en negativo")
        c.execute("UPDATE inventory_products SET quantity=%s,updated_at=NOW() WHERE id=%s",(new,pid))
        c.execute("""INSERT INTO inventory_movements(product_id,user_id,movement_type,quantity_delta,quantity_after,note)
        VALUES(%s,%s,%s,%s,%s,%s)""",(pid,u["id"],d.direction,delta,new,d.note.strip() or ("Entrada manual" if delta>0 else "Salida manual")))
        out=c.execute("SELECT id,sku,name,category,unit,quantity,min_stock,unit_cost,notes,updated_at FROM inventory_products WHERE id=%s",(pid,)).fetchone()
    return pack(out)
@app.get("/inventory/{pid}/movements")
def movements(pid:int,request:Request):
    user_from(request)
    with psycopg.connect(DB) as c:
        if not c.execute("SELECT 1 FROM inventory_products WHERE id=%s AND is_active",(pid,)).fetchone():raise HTTPException(404,"Producto no encontrado")
        rows=c.execute("""SELECT m.id,m.movement_type,m.quantity_delta,m.quantity_after,m.note,m.created_at,u.username
        FROM inventory_movements m LEFT JOIN app_users u ON u.id=m.user_id WHERE m.product_id=%s ORDER BY m.created_at DESC LIMIT 100""",(pid,)).fetchall()
    return {"items":[{"id":r[0],"type":r[1],"delta":r[2],"quantity_after":r[3],"note":r[4],"created_at":r[5],"username":r[6]} for r in rows]}
